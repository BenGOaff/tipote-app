var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/systeme-io/subscriptions/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__fc951bf4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/ce889_server_app_api_systeme-io_subscriptions_cancel_route_actions_afa301ba.js")
R.m(24332)
module.exports=R.m(24332).exports
