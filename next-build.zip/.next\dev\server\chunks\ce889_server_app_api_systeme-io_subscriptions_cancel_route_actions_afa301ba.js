module.exports = [
"[project]/.next-internal/server/app/api/systeme-io/subscriptions/cancel/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_api_systeme-io_subscriptions_cancel_route_actions_afa301ba.js.map