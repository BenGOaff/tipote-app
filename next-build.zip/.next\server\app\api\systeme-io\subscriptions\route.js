var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/systeme-io/subscriptions/route.js")
R.c("server/chunks/[root-of-the-server]__2a9cfa12._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_systeme-io_subscriptions_route_actions_bc8303c8.js")
R.m(39215)
module.exports=R.m(39215).exports
