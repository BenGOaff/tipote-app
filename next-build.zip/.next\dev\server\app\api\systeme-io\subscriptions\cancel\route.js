var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/systeme-io/subscriptions/cancel/route.js")
R.c("server/chunks/node_modules_next_ccc8eb30._.js")
R.c("server/chunks/[root-of-the-server]__72a0c6fb._.js")
R.c("server/chunks/ce889_server_app_api_systeme-io_subscriptions_cancel_route_actions_afa301ba.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/systeme-io/subscriptions/cancel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/systeme-io/subscriptions/cancel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
