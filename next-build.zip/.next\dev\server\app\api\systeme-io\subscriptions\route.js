var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/systeme-io/subscriptions/route.js")
R.c("server/chunks/node_modules_next_ac9b6be0._.js")
R.c("server/chunks/[root-of-the-server]__6a8aa382._.js")
R.c("server/chunks/_next-internal_server_app_api_systeme-io_subscriptions_route_actions_bc8303c8.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/systeme-io/subscriptions/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/systeme-io/subscriptions/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
