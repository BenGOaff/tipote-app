var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/billing/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__5d7d26e2._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_billing_cancel_route_actions_09775195.js")
R.m(68827)
module.exports=R.m(68827).exports
