globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/414e77373f8ff61c.js",
    "static/chunks/73fafc8c6de1ddad.js",
    "static/chunks/afd1130b6f5e67ea.js",
    "static/chunks/4224e4c7f0966e83.js",
    "static/chunks/3ee8b03b18b9c113.js",
    "static/chunks/turbopack-dcd0d19067532168.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];