var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/project-tasks/route.js")
R.c("server/chunks/[root-of-the-server]__425ea336._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_project-tasks_route_actions_e02b8a17.js")
R.m(85574)
module.exports=R.m(85574).exports
