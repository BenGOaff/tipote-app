var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/onboarding/answers/route.js")
R.c("server/chunks/[root-of-the-server]__b1505c82._.js")
R.c("server/chunks/_dfa02d0b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_onboarding_answers_route_actions_1b2c9d3e.js")
R.m(51818)
module.exports=R.m(51818).exports
