module.exports = [
"[project]/.next-internal/server/app/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_app_page_actions_668839a4.js.map