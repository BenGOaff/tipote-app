var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resources/search/route.js")
R.c("server/chunks/[root-of-the-server]__4d5b8578._.js")
R.c("server/chunks/_dfa02d0b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/node_modules_openai_index_mjs_88cf4560._.js")
R.c("server/chunks/_next-internal_server_app_api_resources_search_route_actions_d534b01b.js")
R.m(78498)
module.exports=R.m(78498).exports
