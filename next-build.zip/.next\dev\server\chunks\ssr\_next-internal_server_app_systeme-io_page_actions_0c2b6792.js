module.exports = [
"[project]/.next-internal/server/app/systeme-io/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_systeme-io_page_actions_0c2b6792.js.map