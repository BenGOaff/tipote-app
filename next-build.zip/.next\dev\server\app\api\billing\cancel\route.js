var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/billing/cancel/route.js")
R.c("server/chunks/node_modules_next_e1859488._.js")
R.c("server/chunks/node_modules_@supabase_storage-js_dist_module_829f4f3c._.js")
R.c("server/chunks/node_modules_@supabase_auth-js_dist_module_02e1b12e._.js")
R.c("server/chunks/node_modules_3a885eab._.js")
R.c("server/chunks/[root-of-the-server]__28277066._.js")
R.c("server/chunks/_next-internal_server_app_api_billing_cancel_route_actions_09775195.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/billing/cancel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/billing/cancel/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
