var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/blocks/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1d04d18f._.js")
R.c("server/chunks/_dfa02d0b._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_blocks_[id]_route_actions_065a84e0.js")
R.m(77006)
module.exports=R.m(77006).exports
