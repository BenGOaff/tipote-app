module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/supabaseAdmin.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/supabaseAdmin.ts
__turbopack_context__.s([
    "supabaseAdmin",
    ()=>supabaseAdmin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://mmwyfqfbfkvcnrkyvagv.supabase.co");
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
if (!serviceRoleKey) {
    throw new Error('Missing env SUPABASE_SERVICE_ROLE_KEY');
}
const supabaseAdmin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, serviceRoleKey, {
    auth: {
        autoRefreshToken: false,
        persistSession: false
    }
});
}),
"[project]/lib/systemeIoClient.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/systemeIoClient.ts
// Client pour l'API publique Systeme.io (gestion des subscriptions)
__turbopack_context__.s([
    "cancelSubscriptionOnSystemeIo",
    ()=>cancelSubscriptionOnSystemeIo,
    "listSubscriptionsForContact",
    ()=>listSubscriptionsForContact
]);
const API_BASE = process.env.SYSTEME_IO_API_BASE ?? 'https://api.systeme.io/api';
const API_KEY = process.env.SYSTEME_IO_API_KEY;
if (!API_KEY) {
    throw new Error('SYSTEME_IO_API_KEY is not set in environment variables');
}
/**
 * Construit une URL complète vers l'API Systeme.io
 * en ajoutant uniquement les query params non vides.
 */ function buildSystemeUrl(path, query) {
    const base = API_BASE.replace(/\/+$/, '');
    const full = path.startsWith('/') ? `${base}${path}` : `${base}/${path}`;
    const url = new URL(full);
    if (query) {
        for (const [key, value] of Object.entries(query)){
            if (value === undefined || value === null) continue;
            const stringValue = String(value);
            if (stringValue.trim() === '') continue;
            url.searchParams.set(key, stringValue);
        }
    }
    return url.toString();
}
/**
 * Requête générique Systeme.io.
 * - Ajoute X-API-Key
 * - Parse le JSON si présent
 * - Loggue les erreurs 4xx/5xx
 */ async function systemeIoRequest(path, options = {}) {
    const { method = 'GET', query, body } = options;
    const url = buildSystemeUrl(path, query);
    const headers = {
        'X-API-Key': API_KEY,
        Accept: 'application/json'
    };
    let payload;
    if (body !== undefined) {
        headers['Content-Type'] = 'application/json';
        payload = JSON.stringify(body);
    }
    const res = await fetch(url, {
        method,
        headers,
        body: payload
    });
    const text = await res.text();
    if (!res.ok) {
        let parsed;
        try {
            parsed = text ? JSON.parse(text) : undefined;
        } catch  {
            parsed = text;
        }
        console.error('[Systeme.io API] Error', res.status, res.statusText, 'for', url, parsed);
        const error = new Error(`Systeme.io API error ${res.status}: ${res.statusText}`);
        error.status = res.status;
        error.url = url;
        error.responseBody = parsed;
        throw error;
    }
    if (!text) {
        // ex: 204 No Content
        return undefined;
    }
    try {
        return JSON.parse(text);
    } catch (err) {
        console.error('[Systeme.io API] Failed to parse JSON response for', url, 'raw body:', text);
        throw err;
    }
}
/**
 * Normalise la réponse en un tableau de subscriptions.
 */ function normalizeSubscriptionCollection(data) {
    if (Array.isArray(data)) {
        return data;
    }
    if (data && Array.isArray(data.items)) {
        return data.items;
    }
    return [];
}
async function listSubscriptionsForContact(contactId, options) {
    if (!Number.isFinite(contactId) || contactId < 1) {
        throw new Error(`Invalid Systeme.io contact id: ${contactId}`);
    }
    const limitRaw = options?.limit ?? 50;
    let limit = Math.floor(limitRaw);
    if (!Number.isFinite(limit) || limit < 10) limit = 10;
    if (limit > 100) limit = 100;
    const query = {
        contact: contactId,
        limit
    };
    if (options?.startingAfter !== undefined && Number.isFinite(options.startingAfter)) {
        query.startingAfter = options.startingAfter;
    }
    if (options?.order === 'asc' || options?.order === 'desc') {
        query.order = options.order;
    }
    const raw = await systemeIoRequest('/payment/subscriptions', {
        method: 'GET',
        query
    });
    const subscriptions = normalizeSubscriptionCollection(raw);
    return {
        raw,
        subscriptions
    };
}
async function cancelSubscriptionOnSystemeIo(params) {
    const { id, cancel } = params;
    if (!id) {
        throw new Error('Missing subscription id for Systeme.io cancellation');
    }
    if (!cancel || typeof cancel !== 'string' || cancel.trim() === '') {
        throw new Error('Missing or empty "cancel" value for Systeme.io cancellation');
    }
    const path = `/payment/subscriptions/${encodeURIComponent(String(id))}/cancel`;
    await systemeIoRequest(path, {
        method: 'POST',
        body: {
            cancel
        }
    });
}
}),
"[project]/app/api/billing/subscription/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/billing/subscription/route.ts
__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseAdmin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabaseAdmin.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$systemeIoClient$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/systemeIoClient.ts [app-route] (ecmascript)");
;
;
;
function parseContactId(raw) {
    if (typeof raw === 'number' && Number.isFinite(raw) && raw > 0) {
        return raw;
    }
    if (typeof raw === 'string') {
        const trimmed = raw.trim();
        if (!trimmed) return null;
        const n = Number(trimmed);
        if (Number.isFinite(n) && n > 0) return n;
    }
    return null;
}
async function POST(req) {
    try {
        const body = await req.json().catch(()=>({}));
        const limit = typeof body.limit === 'number' && Number.isFinite(body.limit) ? body.limit : 50;
        const email = body.email?.trim() || null;
        // 1) Déterminer le sio_contact_id (priorité au body)
        let contactId = parseContactId(body.sio_contact_id) ?? parseContactId(body.contactId) ?? parseContactId(body.contact);
        let profile = null;
        // 2) Si pas de contactId direct, on essaye de le récupérer via Supabase
        if (!contactId && email) {
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseAdmin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseAdmin"].from('profiles').select('*').eq('email', email).maybeSingle();
            if (error) {
                console.error('[Billing/subscription] Error fetching profile by email', error);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    error: 'Failed to fetch profile by email'
                }, {
                    status: 500
                });
            }
            profile = data ?? null;
            if (profile?.sio_contact_id) {
                contactId = parseContactId(profile.sio_contact_id);
            }
        } else if (contactId) {
            // 3) On a déjà un contactId → on essaye quand même de récupérer le profil associé
            const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabaseAdmin$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseAdmin"].from('profiles').select('*').eq('sio_contact_id', String(contactId)).maybeSingle();
            if (error) {
                console.error('[Billing/subscription] Error fetching profile by contactId', error);
            // On ne bloque pas si le profil est introuvable, on retournera juste null
            } else {
                profile = data ?? null;
            }
        }
        if (!contactId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Missing sio_contact_id or email, impossible de déterminer le contact Systeme.io'
            }, {
                status: 400
            });
        }
        // 4) Récupérer les abonnements Systeme.io pour ce contact
        const collection = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$systemeIoClient$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listSubscriptionsForContact"])(contactId, {
            limit,
            order: 'desc'
        });
        // Dans ton client Systeme.io, tu renvoies { raw, subscriptions }
        const items = collection.subscriptions ?? [];
        // On essaye d’identifier un abonnement "actif"
        const activeSubscription = items.find((sub)=>String(sub.status ?? '').toLowerCase() === 'active' || String(sub.status ?? '').toLowerCase() === 'trialing') ?? null;
        const latestSubscription = items[0] ?? null;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            contactId,
            limit,
            count: items.length,
            profile,
            subscriptions: items,
            activeSubscription,
            latestSubscription,
            raw: collection.raw ?? collection
        }, {
            status: 200
        });
    } catch (err) {
        console.error('[Billing/subscription] Unexpected error:', err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: err?.message ?? 'Internal server error'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5d2f4088._.js.map