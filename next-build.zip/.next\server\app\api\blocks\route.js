var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/blocks/route.js")
R.c("server/chunks/[root-of-the-server]__afe92f21._.js")
R.c("server/chunks/_dfa02d0b._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_blocks_route_actions_e08247d4.js")
R.m(8492)
module.exports=R.m(8492).exports
