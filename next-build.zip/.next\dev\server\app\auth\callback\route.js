var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/node_modules_next_8f5aded4._.js")
R.c("server/chunks/node_modules_@supabase_storage-js_dist_module_829f4f3c._.js")
R.c("server/chunks/node_modules_@supabase_auth-js_dist_module_02e1b12e._.js")
R.c("server/chunks/node_modules_fccfbb27._.js")
R.c("server/chunks/[root-of-the-server]__db3abce6._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_3740e4d4.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/auth/callback/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/auth/callback/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
