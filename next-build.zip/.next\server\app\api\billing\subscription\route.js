var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/billing/subscription/route.js")
R.c("server/chunks/[root-of-the-server]__d7d20212._.js")
R.c("server/chunks/node_modules_9e1fbe53._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_billing_subscription_route_actions_56045278.js")
R.m(35622)
module.exports=R.m(35622).exports
