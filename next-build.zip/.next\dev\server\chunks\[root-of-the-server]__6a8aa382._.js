module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/systemeIoClient.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/systemeIoClient.ts
// Client pour l'API publique Systeme.io (gestion des subscriptions)
__turbopack_context__.s([
    "cancelSubscriptionOnSystemeIo",
    ()=>cancelSubscriptionOnSystemeIo,
    "listSubscriptionsForContact",
    ()=>listSubscriptionsForContact
]);
const API_BASE = process.env.SYSTEME_IO_API_BASE ?? 'https://api.systeme.io/api';
const API_KEY = process.env.SYSTEME_IO_API_KEY;
if (!API_KEY) {
    throw new Error('SYSTEME_IO_API_KEY is not set in environment variables');
}
/**
 * Construit une URL complète vers l'API Systeme.io
 * en ajoutant uniquement les query params non vides.
 */ function buildSystemeUrl(path, query) {
    const base = API_BASE.replace(/\/+$/, '');
    const full = path.startsWith('/') ? `${base}${path}` : `${base}/${path}`;
    const url = new URL(full);
    if (query) {
        for (const [key, value] of Object.entries(query)){
            if (value === undefined || value === null) continue;
            const stringValue = String(value);
            if (stringValue.trim() === '') continue;
            url.searchParams.set(key, stringValue);
        }
    }
    return url.toString();
}
/**
 * Requête générique Systeme.io.
 * - Ajoute X-API-Key
 * - Parse le JSON si présent
 * - Loggue les erreurs 4xx/5xx
 */ async function systemeIoRequest(path, options = {}) {
    const { method = 'GET', query, body } = options;
    const url = buildSystemeUrl(path, query);
    const headers = {
        'X-API-Key': API_KEY,
        Accept: 'application/json'
    };
    let payload;
    if (body !== undefined) {
        headers['Content-Type'] = 'application/json';
        payload = JSON.stringify(body);
    }
    const res = await fetch(url, {
        method,
        headers,
        body: payload
    });
    const text = await res.text();
    if (!res.ok) {
        let parsed;
        try {
            parsed = text ? JSON.parse(text) : undefined;
        } catch  {
            parsed = text;
        }
        console.error('[Systeme.io API] Error', res.status, res.statusText, 'for', url, parsed);
        const error = new Error(`Systeme.io API error ${res.status}: ${res.statusText}`);
        error.status = res.status;
        error.url = url;
        error.responseBody = parsed;
        throw error;
    }
    if (!text) {
        // ex: 204 No Content
        return undefined;
    }
    try {
        return JSON.parse(text);
    } catch (err) {
        console.error('[Systeme.io API] Failed to parse JSON response for', url, 'raw body:', text);
        throw err;
    }
}
/**
 * Normalise la réponse en un tableau de subscriptions.
 */ function normalizeSubscriptionCollection(data) {
    if (Array.isArray(data)) {
        return data;
    }
    if (data && Array.isArray(data.items)) {
        return data.items;
    }
    return [];
}
async function listSubscriptionsForContact(contactId, options) {
    if (!Number.isFinite(contactId) || contactId < 1) {
        throw new Error(`Invalid Systeme.io contact id: ${contactId}`);
    }
    const limitRaw = options?.limit ?? 50;
    let limit = Math.floor(limitRaw);
    if (!Number.isFinite(limit) || limit < 10) limit = 10;
    if (limit > 100) limit = 100;
    const query = {
        contact: contactId,
        limit
    };
    if (options?.startingAfter !== undefined && Number.isFinite(options.startingAfter)) {
        query.startingAfter = options.startingAfter;
    }
    if (options?.order === 'asc' || options?.order === 'desc') {
        query.order = options.order;
    }
    const raw = await systemeIoRequest('/payment/subscriptions', {
        method: 'GET',
        query
    });
    const subscriptions = normalizeSubscriptionCollection(raw);
    return {
        raw,
        subscriptions
    };
}
async function cancelSubscriptionOnSystemeIo(params) {
    const { id, cancel } = params;
    if (!id) {
        throw new Error('Missing subscription id for Systeme.io cancellation');
    }
    if (!cancel || typeof cancel !== 'string' || cancel.trim() === '') {
        throw new Error('Missing or empty "cancel" value for Systeme.io cancellation');
    }
    const path = `/payment/subscriptions/${encodeURIComponent(String(id))}/cancel`;
    await systemeIoRequest(path, {
        method: 'POST',
        body: {
            cancel
        }
    });
}
}),
"[project]/app/api/systeme-io/subscriptions/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/systeme-io/subscriptions/route.ts
__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$systemeIoClient$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/systemeIoClient.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const body = await request.json().catch(()=>({}));
        const rawContactId = body.sio_contact_id ?? body.contactId ?? body.contact ?? null;
        if (rawContactId === null || rawContactId === undefined) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Missing sio_contact_id (or contactId/contact) in request body'
            }, {
                status: 400
            });
        }
        const contactIdNumber = typeof rawContactId === 'string' ? parseInt(rawContactId, 10) : Number(rawContactId);
        if (!Number.isFinite(contactIdNumber) || contactIdNumber < 1) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `Invalid contact id value: ${rawContactId}`
            }, {
                status: 400
            });
        }
        const limitBody = typeof body.limit === 'number' && Number.isFinite(body.limit) ? body.limit : undefined;
        const { raw, subscriptions } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$systemeIoClient$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listSubscriptionsForContact"])(contactIdNumber, {
            limit: limitBody ?? 50
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            contactId: contactIdNumber,
            subscriptions,
            raw
        }, {
            status: 200
        });
    } catch (error) {
        console.error('[API] /api/systeme-io/subscriptions failed', error);
        const status = typeof error?.status === 'number' && error.status >= 400 && error.status <= 599 ? error.status : 500;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to list subscriptions from Systeme.io',
            details: error?.responseBody ?? error?.message ?? String(error)
        }, {
            status
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6a8aa382._.js.map